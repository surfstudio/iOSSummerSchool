 
import PlaygroundSupport
import Foundation
PlaygroundPage.current.needsIndefiniteExecution = true
//: # Operation
//: `Operation` представляет собой 'задачу'
//: ## простейшая `Operation`
//: используется только совместно c `OperationQueue` с помощью метода `addOperation`
let operation1 = {
    print ("Operation 1 started")
    print ("Operation 1 finished")
}

let queue = OperationQueue()
queue.addOperation(operation1)
//: Полноценная `Operation` может быть сконструирована как `BlockOperation` или как пользовательский subclass `Operation`.
//: ## BlockOperation
//: Создаем `BlockOperation` для конкатенации двух строк
var result: String?

let concatenationOperation = BlockOperation {
    result = "💧" + "☂️"
    sleep(2)
}
duration {
    concatenationOperation.start()
}
result

//: Создаем `BlockOperation` с можеством блоков:
let multiPrinter = BlockOperation()
multiPrinter.completionBlock = {
    print("Finished multiPrinting!")
}

multiPrinter.addExecutionBlock {  print("Каждый 🍎"); sleep(2) }
multiPrinter.addExecutionBlock {  print("Охотник 🍊"); sleep(2) }
multiPrinter.addExecutionBlock {  print("Желает 🍋"); sleep(2) }
multiPrinter.addExecutionBlock {  print("Знать 🍏"); sleep(2) }
multiPrinter.addExecutionBlock {  print("Где 💎"); sleep(2) }
multiPrinter.addExecutionBlock {  print("Сидит 🚙"); sleep(2) }
multiPrinter.addExecutionBlock {  print("Фазан 🍆"); sleep(2) }

duration {
    multiPrinter.start()
}

 
 
 
 
PlaygroundPage.current.finishExecution()
