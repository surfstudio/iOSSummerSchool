//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport
//: Определяем бесконечное выполнение, чтобы предотвратить "выбрасывание" background tasks, когда работа на Playground будет закончена.
PlaygroundPage.current.needsIndefiniteExecution = true

// Создаем
var view = UIView(frame: CGRect(x: 0, y: 200, width: 200, height: 400))
view.backgroundColor = .yellow

var imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
var imageView2 = UIImageView(frame: CGRect(x: 0, y: 200, width: 200, height: 200))
[imageView1, imageView2].forEach {
    $0.contentMode = .scaleAspectFit
    view.addSubview($0)
}

//imageView2.isHidden = true
//imageView1.isHidden = true

//: "Живой" UI
PlaygroundPage.current.liveView = view


func fetchImage(_ imageUrl: String, completion: @escaping (UIImage?) -> Void) {
    guard let imageURL = URL(string: imageUrl) else {
        return
    }
    let queue = DispatchQueue.global(qos: .utility)
    queue.async {
        if let data = try? Data(contentsOf: imageURL){
            DispatchQueue.main.async {
                completion(UIImage(data: data))
            }
        }
    }
}

// загружаем две фотографии без блокировки главного потока

fetchImage("http://www.planetware.com/photos-large/F/france-paris-eiffel-tower.jpg", completion: { (image) in
    imageView1.image = image
})
fetchImage("https://www.cre.ru/content/upload/news/15366547626666.jpg", completion: { (image) in
    imageView2.image = image
})

//// создаем диспатч группу
//let group = DispatchGroup()
//
//// делаем вход в группу
//group.enter()
//
//fetchImage("http://www.planetware.com/photos-large/F/france-paris-eiffel-tower.jpg", completion: { (image) in
//    imageView1.image = image
//    // делаем выход из группы
//    group.leave()
//})
//
//group.enter()
//
//fetchImage("https://www.cre.ru/content/upload/news/15366547626666.jpg", completion: { (image) in
//    imageView2.image = image
//    group.leave()
//})
//
//// когда из группы все уйдут, то вызовется завершающий блок
//group.notify(queue: .main) {
//    imageView2.isHidden = false
//    imageView1.isHidden = false
//}


//: Замечание: Необходимо закомментировать предложение finishExecution чтобы посмотреть результат на main queue в отладочной области и включить Ассистента Редактора, если вы хотите увидеть UI
//PlaygroundPage.current.finishExecution()
//: Остановите Playground вручную, если вы комментируете finishExecution()
